/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenprojecttofu;

/**
 *
 * @author CLASSROOM
 */
public class MavenprojectTofu {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
